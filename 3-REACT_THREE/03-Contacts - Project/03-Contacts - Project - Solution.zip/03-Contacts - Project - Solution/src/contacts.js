const contacts = [
  {
    id: 1,
    name: "Jay-Z",
    imgURL:
      "https://img.vggcdn.net/img/cat/4101/1/37.jpg",
    phone: "+123 456 789",
    email: "jayz@jayz.com"
  },
  {
    id: 2,
    name: "Jack Bauer",
    imgURL:
      "https://dvdbash.files.wordpress.com/2013/09/24-jack-bauer-kiefer-sutherland-080-dvdbash.jpg",
    phone: "+987 654 321",
    email: "jack@nowhere.com"
  },
  {
    id: 3,
    name: "Chuck Norris",
    imgURL:
      "https://i.pinimg.com/originals/e3/94/47/e39447de921955826b1e498ccf9a39af.png",
    phone: "+918 372 574",
    email: "gmail@chucknorris.com"
  }
];

export default contacts;
