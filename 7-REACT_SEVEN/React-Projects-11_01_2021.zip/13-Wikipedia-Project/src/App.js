import React from "react";

function App() {
  
  return (
    <div className="container">
      <h1>Wikipedia Search with Function Component</h1>
      
    </div>
  );
}

export default App;
