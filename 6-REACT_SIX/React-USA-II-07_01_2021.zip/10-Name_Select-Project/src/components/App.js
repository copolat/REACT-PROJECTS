import React from 'react';
import { Select } from './Select';
import { Name } from './Name';

export class App extends React.Component {
  

  render() {
    return (
      <div>
        <Select />
        <Name />
      </div>
    );
  }
}

